import tkinter as tk
from tkinter import messagebox
import random

# --- Datos del Juego ---
personajes = [
    "Mateo el Detective",
    "Sofía la Chef",
    "Carlos el Jardinero",
    "Elena la Doctora",
    "Luis el Músico"
]

armas = [
    "Cuchillo",
    "Pistola",
    "Llave inglesa",
    "Bate de béisbol",
    "Veneno"
]

locaciones = [
    "Cocina",
    "Biblioteca",
    "Jardín",
    "Sala",
    "Habitación Secreta"
]

# --- Historias (5 combinaciones específicas) ---
historias = {
    ("Mateo el Detective", "Llave inglesa", "Biblioteca"): "Mateo descubrió un antiguo secreto y la tensión lo llevó al crimen.",
    ("Sofía la Chef", "Cuchillo", "Cocina"): "Sofía, presa de los celos, usó su cuchillo favorito en un momento de furia.",
    ("Carlos el Jardinero", "Bate de béisbol", "Jardín"): "Carlos encontró al intruso en su jardín y actuó impulsivamente.",
    ("Elena la Doctora", "Veneno", "Sala"): "Elena utilizó sus conocimientos médicos para cometer el crimen discretamente.",
    ("Luis el Músico", "Pistola", "Habitación Secreta"): "Luis, desesperado por un contrato perdido, cometió el acto fatal en secreto."
}

# --- Pistas según elemento ---
pistas_personajes = {
    "Mateo el Detective": "El culpable es alguien que investiga misterios.",
    "Sofía la Chef": "El culpable ama preparar platillos deliciosos.",
    "Carlos el Jardinero": "El culpable trabaja al aire libre con plantas.",
    "Elena la Doctora": "El culpable sabe mucho de medicina.",
    "Luis el Músico": "El culpable toca instrumentos musicales."
}

pistas_armas = {
    "Cuchillo": "El arma era pequeña pero mortal.",
    "Pistola": "Se escuchó un disparo en la escena.",
    "Llave inglesa": "Se usó una herramienta pesada.",
    "Bate de béisbol": "El arma fue un objeto contundente de madera.",
    "Veneno": "La víctima no presentó heridas externas."
}

pistas_locaciones = {
    "Cocina": "El crimen ocurrió donde se cocinan alimentos.",
    "Biblioteca": "El crimen ocurrió entre libros y estantes.",
    "Jardín": "El crimen ocurrió rodeado de naturaleza.",
    "Sala": "El crimen ocurrió en un área de descanso.",
    "Habitación Secreta": "El crimen ocurrió en un lugar oculto."
}

# --- Elección Aleatoria del Misterio ---
culpable_secreto = random.choice(personajes)
arma_secreta = random.choice(armas)
locacion_secreta = random.choice(locaciones)

# --- Selección de una pista aleatoria ---
pistas_disponibles = [
    pistas_personajes[culpable_secreto],
    pistas_armas[arma_secreta],
    pistas_locaciones[locacion_secreta]
]
pista_mostrar = random.choice(pistas_disponibles)

# --- Función para Verificar la Acusación ---
def verificar():
    elegido_personaje = variable_personaje.get()
    elegido_arma = variable_arma.get()
    elegido_locacion = variable_locacion.get()

    errores = []

    if elegido_personaje != culpable_secreto:
        errores.append("Personaje Incorrecto")
    if elegido_arma != arma_secreta:
        errores.append("Arma Incorrecta")
    if elegido_locacion != locacion_secreta:
        errores.append("Lugar Incorrecto")

    if not errores:
        # Buscar historia específica o generar una automáticamente
        historia = historias.get(
            (culpable_secreto, arma_secreta, locacion_secreta),
            f"El crimen ocurrió en la {locacion_secreta} cuando {culpable_secreto} utilizó un(a) {arma_secreta}."
        )
        messagebox.showinfo("¡Ganaste!", f"¡Felicidades, resolviste el misterio!\n\nHistoria:\n{historia}")
        ventana.destroy()
    else:
        mensaje_error = "\n".join(errores)
        messagebox.showwarning("Fallaste", f"{mensaje_error}")

# --- Configuración de Ventana Principal ---
ventana = tk.Tk()
ventana.title("Clue: Misterio")
ventana.geometry("420x350")
ventana.configure(bg="#FFFACD")

titulo = tk.Label(ventana, text="¿Quién cometió el crimen?", font=("Arial", 16, "bold"), bg="#FFFACD")
titulo.pack(pady=10)

# --- Mostrar Pista ---
pista_label = tk.Label(ventana, text=f"Pista: {pista_mostrar}", wraplength=350, bg="#FFFACD", font=("Arial", 10, "italic"))
pista_label.pack(pady=5)

# --- Menús Desplegables ---
variable_personaje = tk.StringVar()
variable_personaje.set(personajes[0])
menu_personaje = tk.OptionMenu(ventana, variable_personaje, *personajes)
menu_personaje.pack(pady=5)

variable_arma = tk.StringVar()
variable_arma.set(armas[0])
menu_arma = tk.OptionMenu(ventana, variable_arma, *armas)
menu_arma.pack(pady=5)

variable_locacion = tk.StringVar()
variable_locacion.set(locaciones[0])
menu_locacion = tk.OptionMenu(ventana, variable_locacion, *locaciones)
menu_locacion.pack(pady=5)

# --- Botón Acusar ---
boton_acusar = tk.Button(ventana, text="Acusar", command=verificar, bg="red", fg="white", font=("Arial", 14, "bold"))
boton_acusar.pack(pady=20)

ventana.mainloop()
