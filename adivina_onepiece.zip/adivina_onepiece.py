import json
import tkinter as tk
from tkinter import messagebox, simpledialog

# Colores personalizados
BG_COLOR = "#1a1a40"
FG_COLOR = "#f5f5f5"
BTN_COLOR = "#3e8e41"
FONT_TITLE = ("Helvetica", 16, "bold")
FONT_TEXT = ("Helvetica", 12)

# Cargar el árbol desde JSON
def cargar_arbol():
    try:
        with open("arbol_onepiece.json", "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

def guardar_arbol(arbol):
    with open("arbol_onepiece.json", "w", encoding="utf-8") as file:
        json.dump(arbol, file, indent=4, ensure_ascii=False)

# Función principal para recorrer el árbol
def hacer_pregunta(nodo, padre=None, rama=None):
    if isinstance(nodo, str):
        acertado = messagebox.askyesno("¿Adiviné bien?", f"¿Tu personaje es {nodo}?")
        if not acertado:
            nuevo_personaje = simpledialog.askstring("¡Oh no!", "¿Cuál era tu personaje?")
            if not nuevo_personaje:
                return
            nueva_pregunta = simpledialog.askstring("Ayúdame a aprender", f"Escribe una pregunta para diferenciar a {nuevo_personaje} de {nodo} (sí para {nuevo_personaje}):")
            if not nueva_pregunta:
                return
            if padre and rama:
                padre[rama] = {
                    "pregunta": nueva_pregunta,
                    "si": nuevo_personaje,
                    "no": nodo
                }
                guardar_arbol(arbol)
                messagebox.showinfo("Gracias", f"¡He aprendido sobre {nuevo_personaje}!")
        else:
            messagebox.showinfo("¡Sí!", "¡Sabía que lo adivinaría!")
        return

    respuesta = messagebox.askyesno("Pregunta", nodo["pregunta"])
    if respuesta:
        hacer_pregunta(nodo["si"], nodo, "si")
    else:
        hacer_pregunta(nodo["no"], nodo, "no")

# Menú principal
def iniciar_juego():
    root.withdraw()
    messagebox.showinfo("Instrucciones", "Piensa en un personaje de One Piece y responde las preguntas con Sí o No.")
    hacer_pregunta(arbol)
    root.deiconify()

# GUI principal
root = tk.Tk()
root.title("¿Adivina quién? One Piece Edition")
root.geometry("500x300")
root.configure(bg=BG_COLOR)

# Cargar árbol
arbol = cargar_arbol()

# Crear frame
frame = tk.Frame(root, bg=BG_COLOR)
frame.pack(expand=True)

titulo = tk.Label(frame, text="¿Adivina Quién? - One Piece Edition", font=FONT_TITLE, fg=FG_COLOR, bg=BG_COLOR)
titulo.pack(pady=20)

jugar_btn = tk.Button(frame, text=" Jugar", font=FONT_TEXT, fg="white", bg=BTN_COLOR, width=20, command=iniciar_juego)
jugar_btn.pack(pady=10)

salir_btn = tk.Button(frame, text=" Salir", font=FONT_TEXT, fg="white", bg="#b22222", width=20, command=root.destroy)
salir_btn.pack(pady=10)

root.mainloop()